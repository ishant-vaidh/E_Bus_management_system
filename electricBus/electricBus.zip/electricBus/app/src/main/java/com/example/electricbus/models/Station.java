package com.example.electricbus.models;

import com.google.android.gms.maps.model.Marker;

public class Station {
    public String name,stationNoString;
    public double latitude,longitude;
    public int  stationNo;
    public Marker marker;
}
