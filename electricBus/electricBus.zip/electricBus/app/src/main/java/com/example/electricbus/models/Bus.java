package com.example.electricbus.models;

import com.google.android.gms.maps.model.Marker;

public class Bus {
    public String Id,status,direction,fromTo,available,KeyId;
    public double latitude,longitude;
    public Marker marker;
}
